# Spring Boot MVC Service Skeleton (Eureka + JWT Resource Server + Common Error)

Skeleton ini adalah template servis berbasis Spring Boot (MVC/Servlet) yang sudah siap:

* Terdaftar ke **Eureka** (service discovery).
* Proteksi **JWT Resource Server** (JWKS dari `auth-service` via service discovery).
* Standarisasi **error JSON** melalui modul `common-web` (RequestId, ErrorResponseBuilder, JSON auth/denied handler).
* **Actuator** (health/info).
* Opsional **JPA + PostgreSQL** (bisa hidup/mati sesuai kebutuhan).
* Sudah ada contoh endpoint `ping`, `secure`, dan `echo` untuk uji akses.

> Setelah init skeleton, cukup **refactor nama servis** dan **ubah port** di `application.yml`.

---

## 1) Prasyarat

* Java 21
* Maven 3.9+
* Docker & Docker Compose
* Service utility yang relevan berjalan (terutama `discovery-service`, `auth-service`, `gateway-service` dan—kalau perlu—`iam-service`)

---

## 2) Ganti Nama Servis & Port

* Cari dan ganti semua kemunculan `sample-service` → **nama servis Anda** (`spring.application.name`, route di gateway, dsb).
* Ubah `server.port` (default contoh: `9200`) di `src/main/resources/application.yml`.

---

## 3) Dependensi (pom.xml)

Sudah disiapkan:

* `spring-boot-starter-web` (MVC/Tomcat)
* `spring-boot-starter-security` & `spring-boot-starter-oauth2-resource-server`
* `spring-boot-starter-actuator`
* `spring-cloud-starter-netflix-eureka-client`
* (Opsional) `spring-boot-starter-data-jpa` + `postgresql`
* `common-web` (untuk error JSON & request-id)

> Jika tidak perlu DB, hapus dependency JPA & Postgres dan blok `spring.datasource` di `application.yml`.

---

## 4) Tambah Route di Gateway

Tambahkan route baru agar trafik lewat Gateway:

```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: sample
          uri: lb://sample-service
          predicates:
            - Path=/sample/**
          filters:
            - StripPrefix=1
```

Akses dari klien: `http://<gateway-host>:<gateway-port>/sample/api/v1/...`

---

## 5) Database (PostgreSQL)

### 5.1 Jika memakai **docker-compose** + file init

Update dua file init Anda agar DB & user untuk servis ini dibuat saat **volume masih kosong**:

**`init-multiple-dbs.sql`**

```sql
-- Tambahkan baris ini:
CREATE DATABASE sample_db WITH ENCODING 'UTF8';
```

**`init-users-and-grants.sql`**

```sql
DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'sample_user')
   THEN CREATE USER sample_user WITH PASSWORD 'sample_pass'; END IF;
END$$;

ALTER DATABASE sample_db OWNER TO sample_user;

GRANT ALL ON DATABASE sample_db TO sample_user;
```

> Tambahan (opsional dan disarankan):
>
> ```sql
> -- Untuk objek yang akan dibuat ke depan:
> ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO sample_user;
> ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO sample_user;
> ```

### 5.2 Jika **volume sudah berisi**, file init **tidak akan dijalankan**

Buat user & DB secara manual:

```bash
docker exec -it tokopaedi-postgres psql -U postgres -c "CREATE USER sample_user WITH PASSWORD 'sample_pass';"
docker exec -it tokopaedi-postgres psql -U postgres -c "CREATE DATABASE sample_db ENCODING 'UTF8' OWNER sample_user;"
docker exec -it tokopaedi-postgres psql -U postgres -d sample_db -c "GRANT ALL ON SCHEMA public TO sample_user;"
docker exec -it tokopaedi-postgres psql -U postgres -d sample_db -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO sample_user;"
# (opsional, tapi baik untuk sequence)
docker exec -it tokopaedi-postgres psql -U postgres -d sample_db -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO sample_user;"
```

Kemudian pastikan `spring.datasource` di `application.yml` mengarah ke `sample_db` dan kredensial `sample_user`.

---

## 6) Build & Run

```bash
# Dari root proyek multi-module
mvn -q -DskipTests clean package

# Jalankan dependency (Eureka, Auth, Gateway, dll) terlebih dahulu
# Lalu jalankan service ini:
java -jar sample-service/target/sample-service-0.0.1-SNAPSHOT.jar
```

---

## 7) Test Endpoint

* **Tanpa token**

  ```
  GET http://<gateway>/sample/api/v1/ping
  → 200 {"message":"pong"}
  ```

* **Dengan token (login lewat Auth-Service)**

   1. Login untuk mendapatkan access token:

      ```
      POST http://<gateway>/auth/api/v1/auth/login
      body: {"usernameOrEmail":"...", "password":"..."}
      ```
   2. Panggil endpoint protected:

      ```
      GET  http://<gateway>/sample/api/v1/secure
      Auth: Bearer <access_token>
      ```
   3. Test Post Protected

      ```
      POST http://<gateway>/sample/api/v1/echo?text=hello
      Auth: Bearer <access_token>
      → 200 {"echo":"hello"}
      ```

> Jika token tidak ada / invalid, response akan terstandarisasi JSON dari `common-web` dengan status 401/403.

---

## 8) Troubleshooting

* **`UnknownHostException: auth-service` pada JWKS**

   * Pastikan `JwtDecoderConfig` pakai `@LoadBalanced RestTemplate` dan JWKS URL adalah `http://auth-service/.well-known/jwks.json`.
   * Pastikan `auth-service` **sudah register** ke Eureka dan **UP**.
   * Pastikan service ini juga **UP** dan dapat resolve `auth-service` melalui Eureka (cek log `eureka-client`).

* **401/403 tapi body kosong**

   * Pastikan Anda sudah mendaftarkan bean `JsonAuthEntryPoint` & `JsonAccessDeniedHandler` dari `common-web` dan dipakai di `exceptionHandling` *serta* `oauth2ResourceServer`.
   * Pastikan `Content-Type` diset `application/json` oleh handler (sudah di-setup di `common-web`).

* **File init Postgres tidak jalan**

   * Cek: kalau volume Postgres sudah berisi data, entrypoint **tidak** menjalankan ulang skrip init. Gunakan cara manual (lihat §9.2).

---

## 9) Catatan Tambahan

* Untuk service baru, cukup:

   1. Duplikasi skeleton ini.
   2. Refactor `artifactId`, package, `spring.application.name`, dan `server.port`.
   3. Tambah route di Gateway (`lb://<nama-service>` + `StripPrefix=1`).
   4. Jika pakai DB, siapkan DB & user (pakai init SQL **atau** manual psql).
   5. Nyalakan semua dependency (Eureka, Auth, Gateway) lalu jalankan service.

> Untuk MVC (Servlet), gunakan `RequestIdFilter`. Untuk Gateway (WebFlux), gunakan `RequestIdWebFilter` (sudah ada di modul `common-web`).